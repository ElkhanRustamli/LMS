package com.example.library;

import com.example.library.dto.request.BookRequest;
import com.example.library.dto.response.BookResponse;
import com.example.library.exception.BookNotFoundException;
import com.example.library.mapper.BookMapper;
import com.example.library.model.Book;
import com.example.library.model.Category;
import com.example.library.repository.BookRepository;
import com.example.library.service.BookService;
import com.example.library.service.CategoryService;
import com.example.library.service.AuthorService;
import com.example.library.service.AmazonS3Service;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.multipart.MultipartFile;

import java.util.Collections;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import static org.junit.jupiter.api.Assertions.*;

class BookServiceTest {

    @Mock private BookRepository bookRepository;
    @Mock private BookMapper bookMapper;
    @Mock private CategoryService categoryService;
    @Mock private AuthorService authorService;
    @Mock private AmazonS3Service amazonS3Service;

    @InjectMocks private BookService bookService;

    private Book book;
    private BookRequest bookRequest;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        book = new Book(1L, "Test Book", 10, "s3Link", null, null, null);
        bookRequest = new BookRequest("Test Book", 10, Collections.singletonList(1L), 1L);
    }

    @Test
    void addBook_shouldCreateNewBook() {
        when(bookMapper.ToEntity(any(BookRequest.class))).thenReturn(book);
        when(categoryService.getCategoryEntityById(anyLong())).thenReturn(new Category());
        when(authorService.getAuthorEntityById(anyLong())).thenReturn(null);
        when(bookRepository.save(any(Book.class))).thenReturn(book);

        bookService.addBook(bookRequest);

        verify(bookRepository, times(1)).save(any(Book.class));
    }

    @Test
    void getBookById_shouldReturnBook_whenBookExists() {
        when(bookRepository.findById(anyLong())).thenReturn(Optional.of(book));
        when(bookMapper.ToResponse(any(Book.class))).thenReturn(new BookResponse(1L, "Test Book", 10, null, null));

        BookResponse response = bookService.getBookById(1L);

        assertEquals("Test Book", response.getTitle());
    }

    @Test
    void getBookById_shouldThrowException_whenBookDoesNotExist() {
        when(bookRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(BookNotFoundException.class, () -> bookService.getBookById(1L));
    }

    @Test
    void getBooks_shouldReturnListOfBooks() {
        when(bookRepository.findAll()).thenReturn(Collections.singletonList(book));
        when(bookMapper.ToResponse(any(Book.class))).thenReturn(new BookResponse(1L, "Test Book", 10, null, null));

        var books = bookService.getBooks();

        assertNotNull(books);
        assertFalse(books.isEmpty());
    }
    @Test
    void updateBook_shouldUpdateExistingBook() {
        // Mock metodları
        when(bookRepository.findById(anyLong())).thenReturn(Optional.of(book));
        doNothing().when(bookMapper).updateEntityFromRequest(any(BookRequest.class), any(Book.class)); // void metod üçün doNothing()
        when(categoryService.getCategoryEntityById(anyLong())).thenReturn(new Category());
        when(authorService.getAuthorEntityById(anyLong())).thenReturn(null);

        // Testi icra et
        bookService.updateBook(1L, bookRequest);

        // Verilənlərin doğruluğunu yoxla
        verify(bookRepository, times(1)).save(any(Book.class)); // save() metodunun bir dəfə çağrıldığını yoxla
    }


    @Test
    void deleteBook_shouldDeleteBook() {
        when(bookRepository.findById(anyLong())).thenReturn(Optional.of(book));

        bookService.deleteBook(1L);

        verify(bookRepository, times(1)).deleteById(anyLong());
    }

    @Test
    void updateBookStock_shouldUpdateStock() {
        when(bookRepository.findById(anyLong())).thenReturn(Optional.of(book));

        bookService.updateBookStock(1L, 20);

        verify(bookRepository, times(1)).save(any(Book.class));
    }

    @Test
    void uploadBookImage_shouldUploadImage() throws Exception {
        MultipartFile file = mock(MultipartFile.class);
        when(file.getOriginalFilename()).thenReturn("book-image.jpg");
        when(file.getInputStream()).thenReturn(getClass().getResourceAsStream("/test.jpg"));
        when(bookRepository.findById(anyLong())).thenReturn(Optional.of(book));

        bookService.uploadBookImage(1L, file);

        verify(amazonS3Service, times(1)).uploadFile(anyString(), any(), anyLong(), anyString());
    }
}
