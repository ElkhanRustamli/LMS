package com.example.library;


import com.example.library.dto.request.CategoryRequest;
import com.example.library.dto.response.CategoryResponse;
import com.example.library.exception.CategoryNotFoundException;
import com.example.library.mapper.CategoryMapper;
import com.example.library.model.Category;
import com.example.library.repository.CategoryRepository;
import com.example.library.service.CategoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CategoryServiceTest {

    @Mock
    private CategoryRepository categoryRepository;

    @Mock
    private CategoryMapper categoryMapper;

    @InjectMocks
    private CategoryService categoryService;

    private Category category;
    private CategoryRequest categoryRequest;
    private CategoryResponse categoryResponse;

    @BeforeEach
    void setUp() {
        category = new Category(1L, "Science", null);
        categoryRequest = new CategoryRequest("Science");
        categoryResponse = new CategoryResponse(1L, "Science");
    }

    @Test
    void addCategory_ShouldSaveCategory() {
        when(categoryMapper.ToEntity(categoryRequest)).thenReturn(category);
        when(categoryRepository.save(category)).thenReturn(category);

        categoryService.addCategory(categoryRequest);

        verify(categoryRepository, times(1)).save(category);
    }

    @Test
    void getCategoryById_ShouldReturnCategoryResponse() {
        when(categoryRepository.findById(1L)).thenReturn(Optional.of(category));
        when(categoryMapper.ToResponse(category)).thenReturn(categoryResponse);

        CategoryResponse response = categoryService.getCategoryById(1L);

        assertNotNull(response);
        assertEquals(categoryResponse.getId(), response.getId());
        assertEquals(categoryResponse.getName(), response.getName());
        verify(categoryRepository, times(1)).findById(1L);
    }

    @Test
    void getCategoryById_ShouldThrowException_WhenCategoryNotFound() {
        when(categoryRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(CategoryNotFoundException.class, () -> categoryService.getCategoryById(1L));
    }

    @Test
    void getAllCategories_ShouldReturnListOfCategoryResponses() {
        List<Category> categories = Arrays.asList(category);
        List<CategoryResponse> responses = Arrays.asList(categoryResponse);

        when(categoryRepository.findAll()).thenReturn(categories);
        when(categoryMapper.ToResponse(category)).thenReturn(categoryResponse);

        List<CategoryResponse> result = categoryService.getAllCategories();

        assertEquals(responses.size(), result.size());
        assertEquals(responses.get(0).getId(), result.get(0).getId());
        verify(categoryRepository, times(1)).findAll();
    }

    @Test
    void updateCategory_ShouldUpdateExistingCategory() {
        when(categoryRepository.findById(1L)).thenReturn(Optional.of(category));

        categoryService.updateCategory(1L, categoryRequest);

        verify(categoryMapper, times(1)).updateEntityFromRequest(eq(categoryRequest), any(Category.class));
        verify(categoryRepository, times(1)).save(category);
    }

    @Test
    void deleteCategory_ShouldDeleteCategoryById() {
        categoryService.deleteCategory(1L);

        verify(categoryRepository, times(1)).deleteById(1L);
    }
}
