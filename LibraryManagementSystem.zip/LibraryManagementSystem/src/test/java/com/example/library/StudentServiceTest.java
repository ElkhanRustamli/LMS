package com.example.library;



import com.example.library.dto.request.StudentRequest;
import com.example.library.dto.response.StudentResponse;
import com.example.library.exception.FinCodeAlreadyExistsException;
import com.example.library.exception.StudentNotFoundException;
import com.example.library.mapper.StudentMapper;
import com.example.library.model.Student;
import com.example.library.repository.StudentRepository;
import com.example.library.service.StudentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class StudentServiceTest {

    @Mock
    private StudentRepository studentRepository;

    @Mock
    private StudentMapper studentMapper;

    @InjectMocks
    private StudentService studentService;

    private Student student;
    private StudentRequest studentRequest;
    private StudentResponse studentResponse;

    @BeforeEach
    void setUp() {
        student = Student.builder()
                .id(1L)
                .finCode("ABC123")
                .firstName("John")
                .lastName("Doe")
                .email("john@example.com")
                .phoneNumber("123456789")
                .age(20)
                .build();

        studentRequest = StudentRequest.builder()
                .finCode("ABC123")
                .firstName("John")
                .lastName("Doe")
                .email("john@example.com")
                .phoneNumber("123456789")
                .age(20)
                .build();

        studentResponse = StudentResponse.builder()
                .id(1L)
                .finCode("ABC123")
                .firstName("John")
                .lastName("Doe")
                .email("john@example.com")
                .phoneNumber("123456789")
                .age(20)
                .build();
    }

    @Test
    void addStudent_ShouldAddStudent_WhenFinCodeDoesNotExist() {
        when(studentRepository.findByFinCode(studentRequest.getFinCode())).thenReturn(Optional.empty());
        when(studentMapper.ToEntity(studentRequest)).thenReturn(student);

        studentService.addStudent(studentRequest);

        verify(studentRepository, times(1)).save(student);
    }

    @Test
    void addStudent_ShouldThrowException_WhenFinCodeExists() {
        when(studentRepository.findByFinCode(studentRequest.getFinCode())).thenReturn(Optional.of(student));

        assertThrows(FinCodeAlreadyExistsException.class, () -> studentService.addStudent(studentRequest));
    }

    @Test
    void getStudentByFinCode_ShouldReturnStudentResponse_WhenStudentExists() {
        when(studentRepository.findByFinCode("ABC123")).thenReturn(Optional.of(student));
        when(studentMapper.ToResponse(student)).thenReturn(studentResponse);

        StudentResponse response = studentService.getStudentByFinCode("ABC123");

        assertNotNull(response);
        assertEquals("ABC123", response.getFinCode());
    }

    @Test
    void getStudentByFinCode_ShouldThrowException_WhenStudentDoesNotExist() {
        when(studentRepository.findByFinCode("XYZ789")).thenReturn(Optional.empty());

        assertThrows(StudentNotFoundException.class, () -> studentService.getStudentByFinCode("XYZ789"));
    }

    @Test
    void updateStudent_ShouldUpdateStudent_WhenStudentExists() {
        when(studentRepository.findById(1L)).thenReturn(Optional.of(student));

        studentService.updateStudent(1L, studentRequest);

        verify(studentRepository, times(1)).save(student);
    }

    @Test
    void updateStudent_ShouldThrowException_WhenStudentDoesNotExist() {
        when(studentRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(StudentNotFoundException.class, () -> studentService.updateStudent(1L, studentRequest));
    }

    @Test
    void deleteStudent_ShouldDeleteStudent_WhenStudentExists() {
        when(studentRepository.findById(1L)).thenReturn(Optional.of(student));

        studentService.deleteStudent(1L);

        verify(studentRepository, times(1)).deleteById(1L);
    }

    @Test
    void deleteStudent_ShouldThrowException_WhenStudentDoesNotExist() {
        when(studentRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(StudentNotFoundException.class, () -> studentService.deleteStudent(1L));
    }
}
