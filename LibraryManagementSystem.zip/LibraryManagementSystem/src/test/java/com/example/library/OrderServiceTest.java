package com.example.library;



import com.example.library.dto.request.OrderRequest;
import com.example.library.dto.response.OrderResponse;
import com.example.library.exception.BookNotFoundException;
import com.example.library.exception.OrderNotFoundException;
import com.example.library.exception.StudentNotFoundException;
import com.example.library.mapper.OrderMapper;
import com.example.library.model.Book;
import com.example.library.model.Order;
import com.example.library.model.Student;
import com.example.library.repository.OrderRepository;
import com.example.library.service.BookService;
import com.example.library.service.OrderService;
import com.example.library.service.StudentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;

import static org.junit.jupiter.api.Assertions.*;

class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private OrderMapper orderMapper;

    @Mock
    private BookService bookService;

    @Mock
    private StudentService studentService;

    @InjectMocks
    private OrderService orderService;

    private OrderRequest orderRequest;
    private Book book;
    private Student student;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Initializing objects
        book = new Book();
        book.setId(1L);
        book.setTitle("Test Book");

        student = new Student();
        student.setId(1L);


        orderRequest = new OrderRequest();
        orderRequest.setBookId(book.getId());
        orderRequest.setStudentId(student.getId());

        // Inject the mock dependencies
        ReflectionTestUtils.setField(orderService, "orderRepository", orderRepository);
        ReflectionTestUtils.setField(orderService, "orderMapper", orderMapper);
        ReflectionTestUtils.setField(orderService, "bookService", bookService);
        ReflectionTestUtils.setField(orderService, "studentService", studentService);
    }

    @Test
    void getOrders_Success() {
        // Arrange: Mocking the retrieval of all orders
        Order order = new Order();
        order.setId(1L);
        order.setBook(book);
        order.setStudent(student);
        List<Order> orders = List.of(order);

        when(orderRepository.findAll()).thenReturn(orders);
        when(orderMapper.ToResponse(order)).thenReturn(new OrderResponse(order.getId(), order.getOrderTimestamp(), order.getReturnTimestamp(), null, null));

        // Act: Call the getOrders method
        List<OrderResponse> orderResponses = orderService.getOrders();

        // Assert: Verifying the result
        assertEquals(1, orderResponses.size());
        verify(orderRepository, times(1)).findAll();
    }

    @Test
    void getOrderById_Success() {
        // Arrange: Mocking the retrieval of an order by ID
        Order order = new Order();
        order.setId(1L);
        order.setBook(book);
        order.setStudent(student);

        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderMapper.ToResponse(order)).thenReturn(new OrderResponse(order.getId(), order.getOrderTimestamp(), order.getReturnTimestamp(), null, null));

        // Act: Call the getOrderById method
        OrderResponse orderResponse = orderService.getOrderById(1L);

        // Assert: Verifying the result
        assertNotNull(orderResponse);
        assertEquals(1L, orderResponse.getId());
    }

    @Test
    void getOrderById_OrderNotFound() {
        // Arrange: Mocking the case when the order is not found
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert: Verifying the exception is thrown when the order is not found
        assertThrows(OrderNotFoundException.class, () -> orderService.getOrderById(1L));
    }

    @Test
    void getOrdersByStudentId_Success() {
        // Arrange: Mocking the retrieval of orders for a student
        Order order = new Order();
        order.setId(1L);
        order.setBook(book);
        order.setStudent(student);
        List<Order> orders = List.of(order);


        when(orderRepository.findByStudent(student)).thenReturn(orders);
        when(orderMapper.ToResponse(order)).thenReturn(new OrderResponse(order.getId(), order.getOrderTimestamp(), order.getReturnTimestamp(), null, null));

        // Act: Call the getOrdersByStudentId method
        List<OrderResponse> orderResponses = orderService.getOrdersByStudentId(1L);

        // Assert: Verifying the result
        assertEquals(1, orderResponses.size());
        verify(orderRepository, times(1)).findByStudent(student);
    }

    @Test
    void updateOrder_Success() {
        // Arrange: Mocking the retrieval of an order by ID
        Order order = new Order();
        order.setId(1L);
        order.setBook(book);
        order.setStudent(student);

        OrderRequest updatedRequest = new OrderRequest(1L, 1L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        // Act: Call the updateOrder method
        orderService.updateOrder(1L, updatedRequest);

        // Assert: Verifying the update logic
        verify(orderRepository, times(1)).save(order);
    }

    @Test
    void updateOrder_OrderNotFound() {
        // Arrange: Mocking the case when the order is not found
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert: Verifying the exception is thrown when the order is not found
        assertThrows(OrderNotFoundException.class, () -> orderService.updateOrder(1L, orderRequest));
    }

    @Test
    void deleteOrder_Success() {
        // Arrange: Mocking the deletion of an order by ID
        Order order = new Order();
        order.setId(1L);
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        // Act: Call the deleteOrder method
        orderService.deleteOrder(1L);

        // Assert: Verifying the deletion logic
        verify(orderRepository, times(1)).deleteById(1L);
    }

    @Test
    void deleteOrder_OrderNotFound() {
        // Arrange: Mocking the case when the order is not found
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert: Verifying the exception is thrown when the order is not found
        assertThrows(OrderNotFoundException.class, () -> orderService.deleteOrder(1L));
    }

    @Test
    void returnOrderBook_Success() {
        // Arrange: Mocking the return of an order
        Order order = new Order();
        order.setId(1L);
        order.setBook(book);
        order.setStudent(student);
        order.setOrderTimestamp(LocalDateTime.now());
        order.setReturnTimestamp(null);

        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        // Act: Call the returnOrderBook method
        orderService.returnOrderBook(1L);

        // Assert: Verifying the return logic
        verify(bookService, times(1)).updateBookStock(book.getId(), book.getStock() + 1);
        verify(orderRepository, times(1)).deleteById(1L);
    }

    @Test
    void returnOrderBook_OrderNotFound() {
        // Arrange: Mocking the case when the order is not found
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert: Verifying the exception is thrown when the order is not found
        assertThrows(OrderNotFoundException.class, () -> orderService.returnOrderBook(1L));
    }
}
