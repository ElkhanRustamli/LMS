package com.example.library;

import com.example.library.dto.request.AuthorRequest;
import com.example.library.dto.response.AuthorResponse;
import com.example.library.exception.AuthorNotFoundException;
import com.example.library.mapper.AuthorMapper;
import com.example.library.model.Author;
import com.example.library.repository.AuthorRepository;
import com.example.library.service.AuthorService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthorServiceTest {

    @Mock
    private AuthorRepository authorRepository;

    @Mock
    private AuthorMapper authorMapper;

    @InjectMocks
    private AuthorService authorService;

    private Author author;
    private AuthorRequest authorRequest;
    private AuthorResponse authorResponse;

    @BeforeEach
    void setUp() {
        author = new Author(1L, "John", "Doe", "Biography", List.of());
        authorRequest = new AuthorRequest("John", "Doe", "Biography");
        authorResponse = new AuthorResponse(1L, "John", "Doe", "Biography");
    }

    @Test
    void testAddAuthor() {
        when(authorMapper.ToEntity(authorRequest)).thenReturn(author);
        when(authorRepository.save(author)).thenReturn(author);

        assertDoesNotThrow(() -> authorService.addAuthor(authorRequest));
        verify(authorRepository, times(1)).save(author);
    }

    @Test
    void testUpdateAuthor_Success() {
        when(authorRepository.findById(1L)).thenReturn(Optional.of(author));
        doNothing().when(authorMapper).updateEntityFromRequest(authorRequest, author);
        when(authorRepository.save(author)).thenReturn(author);

        assertDoesNotThrow(() -> authorService.updateAuthor(1L, authorRequest));
        verify(authorRepository, times(1)).save(author);
    }

    @Test
    void testUpdateAuthor_NotFound() {
        when(authorRepository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(AuthorNotFoundException.class, () -> authorService.updateAuthor(1L, authorRequest));
    }

    @Test
    void testDeleteAuthor() {
        doNothing().when(authorRepository).deleteById(1L);
        assertDoesNotThrow(() -> authorService.deleteAuthor(1L));
        verify(authorRepository, times(1)).deleteById(1L);
    }

    @Test
    void testGetAuthorById_Success() {
        when(authorRepository.findById(1L)).thenReturn(Optional.of(author));
        when(authorMapper.ToResponse(author)).thenReturn(authorResponse);

        AuthorResponse response = authorService.getAuthorById(1L);
        assertNotNull(response);
        assertEquals(authorResponse.getId(), response.getId());
    }

    @Test
    void testGetAuthorById_NotFound() {
        when(authorRepository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(AuthorNotFoundException.class, () -> authorService.getAuthorById(1L));
    }

    @Test
    void testGetAuthors() {
        when(authorRepository.findAll()).thenReturn(List.of(author));
        when(authorMapper.ToResponse(author)).thenReturn(authorResponse);

        List<AuthorResponse> responses = authorService.getAuthors();
        assertEquals(1, responses.size());
    }

    @Test
    void testGetAuthorsByFullName() {
        when(authorRepository.searchByFullName("John Doe")).thenReturn(List.of(author));
        when(authorMapper.ToResponse(author)).thenReturn(authorResponse);

        List<AuthorResponse> responses = authorService.getAuthorsByFullName("John Doe");
        assertEquals(1, responses.size());
    }

    @Test
    void testGetAuthorsSortedByBookCount() {
        when(authorRepository.findAllOrderByBookCountDesc()).thenReturn(List.of(author));
        when(authorMapper.ToResponse(author)).thenReturn(authorResponse);

        List<AuthorResponse> responses = authorService.getAuthorsSortedByBookCount();
        assertEquals(1, responses.size());
    }
}
