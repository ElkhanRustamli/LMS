package com.example.library.dto.response;

import lombok.*;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderResponse 
{
    private long id; 
    private LocalDateTime orderTimestamp; 
    private LocalDateTime returnTimestamp;

    @ToString.Exclude
    private BookResponse book; 
    
    @ToString.Exclude
    private StudentResponse student; 
}
