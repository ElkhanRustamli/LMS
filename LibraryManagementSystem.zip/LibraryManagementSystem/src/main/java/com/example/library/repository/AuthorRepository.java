package com.example.library.repository;

import com.example.library.model.Author;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AuthorRepository extends JpaRepository<Author, Long>
{
    @Query("""
    SELECT a FROM Author a
    WHERE LOWER(CONCAT(a.firstname, ' ', a.lastname, ' ', a.biography)) LIKE LOWER(CONCAT('%', :fullName, '%'))
    OR LOWER(a.firstname) LIKE LOWER(CONCAT('%', :fullName, '%'))
    OR LOWER(a.lastname) LIKE LOWER(CONCAT('%', :fullName, '%'))
    OR LOWER(a.biography) LIKE LOWER(CONCAT('%', :fullName, '%'))
""")
    List<Author> searchByFullName(@Param("fullName") String fullName);

    @Query("SELECT a FROM Author a ORDER BY SIZE(a.books) DESC")
    List<Author> findAllOrderByBookCountDesc();

}

