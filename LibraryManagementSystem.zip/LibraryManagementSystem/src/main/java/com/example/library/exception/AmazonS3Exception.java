package com.example.library.exception;

public class AmazonS3Exception extends RuntimeException
{
    public AmazonS3Exception(String message)
    {
        super(message);
    }
}
