package com.example.library.service;
import com.example.library.exception.UserNotFoundException;
import com.example.library.dto.request.LoginRequest;
import com.example.library.model.User;
import com.example.library.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.JwsHeader;
import org.springframework.security.oauth2.jwt.JwtClaimsSet;
import org.springframework.security.oauth2.jwt.JwtEncoder;
import org.springframework.security.oauth2.jwt.JwtEncoderParameters;
import org.springframework.stereotype.Service;
import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthService {

    private final JwtEncoder jwtEncoder;
    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;

    @Value("${app.security.jwt.issuer}")
    private String jwtIssuer;

    // Admin istifadəçisi üçün doğrulama və token yaradır
    public String authenticateAdminUser(LoginRequest loginRequest) {
        authenticateUser(loginRequest);

        User user = getUserEntity(loginRequest.getUsername());

        String token = generateJwtToken(user);
        log.info("Administrator {} has successfully logged in", loginRequest.getUsername());

        return token;
    }

    // İstifadəçi məlumatlarını doğrulayan metod
    private void authenticateUser(LoginRequest loginRequest) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()
                )
        );
    }

    // İstifadəçi məlumatlarını əldə edən metod
    private User getUserEntity(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new UserNotFoundException("No admin found with username: " + username));
    }

    // JWT token yaratmaq
    private String generateJwtToken(User user) {
        Instant now = Instant.now();
        JwtClaimsSet claims = JwtClaimsSet.builder()
                .issuer(jwtIssuer)
                .issuedAt(now)
                .expiresAt(now.plusSeconds(3600 * 12))
                .subject(user.getUsername())
                .claim("roles", List.of("ROLE_ADMIN"))
                .build();

        JwtEncoderParameters params = JwtEncoderParameters
                .from(JwsHeader.with(MacAlgorithm.HS256).build(), claims);
        return jwtEncoder.encode(params).getTokenValue();
    }
}

