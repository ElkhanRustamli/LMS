package com.example.library.controller;
import com.example.library.dto.request.CategoryRequest;
import com.example.library.dto.response.CategoryResponse;
import com.example.library.service.CategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping(value = "/api/category")
public class CategoryController 
{
    private final CategoryService categoryService; 

    @PostMapping(value = "add")
    @ResponseStatus(value = HttpStatus.CREATED)
    public void addCategory(@RequestBody CategoryRequest categoryRequest)
    {
        categoryService.addCategory(categoryRequest);
    }

    @DeleteMapping(value = "/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public void deleteCategory(@PathVariable(value = "id") long categoryId)
    {
        categoryService.deleteCategory(categoryId);
    }

    @PutMapping(value = "/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public void updateCategory(
            @PathVariable(value = "id") long categoryId,
            @RequestBody CategoryRequest categoryRequest
    ){
        categoryService.updateCategory(categoryId, categoryRequest);
    }

    @GetMapping("/search-categories-name")
    @ResponseStatus(HttpStatus.OK)
    public List<CategoryResponse> searchCategories(@RequestParam String name) {
        return categoryService.searchCategoriesByName(name);
    }

    @GetMapping
    @ResponseStatus(value = HttpStatus.OK)
    public List<CategoryResponse> getAllCategories()
    {
        return categoryService.getAllCategories();
    }

    @GetMapping(value = "/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public CategoryResponse getCategoryById(@PathVariable(value = "id") long categoryId)
    {
        return categoryService.getCategoryById(categoryId);
    }

    @GetMapping("/sorted-by-books")
    @ResponseStatus(HttpStatus.OK)
    public List<CategoryResponse> getCategoriesSortedByBookCount() {
        return categoryService.getCategoriesSortedByBookCount();
    }
}
