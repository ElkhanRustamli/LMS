package com.example.library.controller;
import com.example.library.dto.request.LoginRequest;
import com.example.library.dto.response.LoginResponse;
import com.example.library.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/authenticate")
    public LoginResponse authenticateAdminUser(@RequestBody LoginRequest loginRequest) {
        String token = authService.authenticateAdminUser(loginRequest);
        return new LoginResponse(token);
    }
}
