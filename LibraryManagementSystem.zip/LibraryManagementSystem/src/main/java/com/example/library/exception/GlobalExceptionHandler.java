package com.example.library.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler 
{
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    @ExceptionHandler(value = AuthorNotFoundException.class)
    public String handleAuthorNotFoundException(AuthorNotFoundException exception)
    {
        return exception.getMessage();
    }

    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    @ExceptionHandler(value = CategoryNotFoundException.class)
    public String handleCategoryNotFoundException(CategoryNotFoundException exception)
    {
        return exception.getMessage(); 
    }

    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    @ExceptionHandler(value = BookNotFoundException.class)
    public String handleBookNotFoundException(BookNotFoundException exception)
    {
        return exception.getMessage();
    }

    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    @ExceptionHandler(value = StudentNotFoundException.class)
    public String handleStudentNotFoundException(StudentNotFoundException exception)
    {
        return exception.getMessage();
    }
    
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    @ExceptionHandler(value = OrderNotFoundException.class)
    public String handleOrderNotFoundException(OrderNotFoundException exception)
    {
        return exception.getMessage();
    }

    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    @ExceptionHandler(value = FinCodeAlreadyExistsException.class)
    public String handleFinCodeAlreadyExistsException(FinCodeAlreadyExistsException exception)
    {
        return exception.getMessage(); 
    }

    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(value = AmazonS3Exception.class)
    public String handleAmazonS3Exception(AmazonS3Exception exception)
    {
        return exception.getMessage(); 
    }

    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    @ExceptionHandler(value = UserNotFoundException.class)
    public String handleAdminUserNotFoundException(UserNotFoundException exception)
    {
        return exception.getMessage();
    }


}
