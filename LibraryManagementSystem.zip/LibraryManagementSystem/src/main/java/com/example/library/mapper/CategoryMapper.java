package com.example.library.mapper;

import com.example.library.dto.request.CategoryRequest;
import com.example.library.dto.response.CategoryResponse;
import com.example.library.model.Category;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface CategoryMapper 
{
     Category ToEntity(CategoryRequest request);
     CategoryResponse ToResponse(Category entity);
     void updateEntityFromRequest(CategoryRequest request, @MappingTarget Category entity);
}
