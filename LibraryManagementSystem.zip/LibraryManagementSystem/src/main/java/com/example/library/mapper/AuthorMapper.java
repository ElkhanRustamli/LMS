package com.example.library.mapper;
import com.example.library.dto.request.AuthorRequest;
import com.example.library.dto.response.AuthorResponse;
import com.example.library.model.Author;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface AuthorMapper 
{
    Author ToEntity(AuthorRequest request);
     AuthorResponse ToResponse(Author entity);
     void updateEntityFromRequest(AuthorRequest request, @MappingTarget Author entity);
}
