package com.example.library.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Data
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "authors")
public class Author
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; 

    @Column(nullable = false)
    private String firstname;

    @Column(nullable = false)
    private String lastname;
    private String biography;

    @ToString.Exclude
    @ManyToMany(mappedBy = "authors")
    private List<Book> books;
}
