package com.example.library.service;
import com.example.library.exception.AmazonS3Exception;
import com.example.library.exception.BookNotFoundException;
import com.example.library.mapper.BookMapper;
import com.example.library.dto.request.BookRequest;
import com.example.library.dto.response.BookImageResponse;
import com.example.library.dto.response.BookResponse;
import com.example.library.model.Book;
import com.example.library.repository.BookRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.stream.Collectors;
@Slf4j
@Service
@RequiredArgsConstructor
public class BookService
{
    private final BookRepository bookRepository;
    private final BookMapper bookMapper;
    private final CategoryService categoryService;
    private final AuthorService authorService;
    private final AmazonS3Service amazonS3Service;
    @Value("${app.image-storage-default-image-file-name.books}")
    private String defaultImageFileName;
    @Value("${app.image-storage-folders.books}")
    private String imageFolder;

    @Transactional
    public void addBook(BookRequest bookRequest)
    {
        Book book = bookMapper.ToEntity(bookRequest);

        book.setCategory(categoryService.getCategoryEntityById(bookRequest.getCategoryId()));
        book.setAuthors(
                bookRequest.getAuthorIds().stream().map(authorService::getAuthorEntityById).collect(Collectors.toList())
        );
        bookRepository.save(book);
        log.info("A new book has been created: {}", book.getTitle());
    }

    @Transactional
    public void updateBook(long bookId, BookRequest bookRequest)
    {  Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new BookNotFoundException("No book found with the given id: " + bookId));

        bookMapper.updateEntityFromRequest(bookRequest, book);

        book.setCategory(categoryService.getCategoryEntityById(bookRequest.getCategoryId()));
        book.setAuthors(
                bookRequest.getAuthorIds().stream().map(authorService::getAuthorEntityById).collect(Collectors.toList())
        );
        bookRepository.save(book);
        log.info("Book with id: {} has been updated", bookId);
    }

    @Transactional
    public void deleteBook(long bookId)
    {
        bookRepository.deleteById(bookId);

        log.info("Book with id: {} has been deleted", bookId);
    }

    public BookResponse getBookById(long bookId)
    {
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new BookNotFoundException("No book found with the given id: " + bookId));

        BookResponse bookResponse = bookMapper.ToResponse(book);
        log.info("Successfully fetched book with id: {}", bookId);
        return bookResponse;
    }

    public List<BookResponse> getBooks() {
        List<Book> bookEntities = bookRepository.findAll();

        return bookEntities.stream()
                .map(bookMapper::ToResponse)
                .collect(Collectors.toList());
    }

    public List<BookResponse> getBooksByCategoryId(long categoryId) {
        List<Book> bookEntities = bookRepository
                .findByCategory(categoryService.getCategoryEntityById(categoryId));

        return bookEntities.stream()
                .map(bookMapper::ToResponse)
                .collect(Collectors.toList());
    }

    public List<BookResponse> getBooksByAuthorId(long authorId) {
        List<Book> bookEntities = bookRepository.findByAuthor(authorService.getAuthorEntityById(authorId));

        return bookEntities.stream()
                .map(bookMapper::ToResponse)
                .collect(Collectors.toList());
    }

    public List<BookResponse> searchBooksByTitle(String bookTitle) {
        List<Book> bookEntities = bookRepository.searchByTitle(bookTitle);

        return bookEntities.stream()
                .map(bookMapper::ToResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public void updateBookStock(long bookId, int stock)
    {
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new BookNotFoundException("No book found with the given id: " + bookId));

        if (stock >= 0)
        {

            book.setStock(stock);
            bookRepository.save(book);
        }
        log.info("Stock for book with id: {} has been updated", bookId);
    }

    @Transactional
    public void uploadBookImage(long bookId, MultipartFile bookImage) {

        Book book = getBookEntityById(bookId);

        String imageName = bookImage.getOriginalFilename();
        if (imageName == null || !imageName.contains(".")) {
            throw new IllegalArgumentException("Invalid file name");
        }
        String fileExtension = imageName.substring(imageName.lastIndexOf("."));
        String fileLink = imageFolder + "/" + book.getId() + fileExtension;
        try (InputStream inputStream = bookImage.getInputStream()) {

            amazonS3Service.uploadFile(fileLink, inputStream, bookImage.getSize(), bookImage.getContentType());

            book.setS3Link(fileLink);
            bookRepository.save(book);

            log.info("Image for book with id: {} has been successfully uploaded", bookId);
        } catch (IOException e) {
            log.error("Error while uploading book image: {}", e.getMessage());
            throw new AmazonS3Exception("Failed to upload book image: " + e.getMessage());
        }
    }

    public BookImageResponse getBookImage(long bookId) {
        Book book = getBookEntityById(bookId);

        String fileLink = book.getS3Link();
        if (fileLink == null) {
            fileLink = imageFolder + "/" + defaultImageFileName; // Default şəkil
        }

        BookImageResponse imageResponse = amazonS3Service.getFile(fileLink);

        log.info("Image successfully retrieved for book with id: {}", book.getId());

        return BookImageResponse.builder()
                .fileLink(fileLink)
                .imageData(imageResponse.getImageData())
                .contentType(imageResponse.getContentType())
                .build();
    }

    protected Book getBookEntityById(long bookId)
    {
        return bookRepository.findById(bookId)
                .orElseThrow(() -> new BookNotFoundException("No book found with the given id: " + bookId));
    }
}
