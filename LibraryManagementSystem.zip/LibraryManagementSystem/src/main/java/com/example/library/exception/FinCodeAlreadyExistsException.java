package com.example.library.exception;

public class FinCodeAlreadyExistsException extends RuntimeException
{
    public FinCodeAlreadyExistsException(String message)
    {
        super(message);
    }    
}
