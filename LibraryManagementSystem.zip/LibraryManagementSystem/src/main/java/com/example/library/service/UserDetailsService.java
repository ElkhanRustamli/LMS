package com.example.library.service;
import com.example.library.exception.UserNotFoundException;
import com.example.library.model.User;
import com.example.library.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


@Service
@RequiredArgsConstructor
public class UserDetailsService implements org.springframework.security.core.userdetails.UserDetailsService {


    private final UserRepository userRepository;
     // İstifadəçi adı (username) əsasında istifadəçi məlumatlarını tapır.

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Verilən username-ə uyğun istifadəçini bazadan axtarır
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UserNotFoundException("No admin found with username: " + username));

        // Tapılan istifadəçidən UserDetails obyektini yaradır və qaytarır
        return org.springframework.security.core.userdetails.User.withUsername(user.getUsername())
                .password(user.getPassword())
                .roles("ADMIN")
                .build();
    }
}
