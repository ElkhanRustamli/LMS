package com.example.library.mapper;

import com.example.library.dto.request.BookRequest;
import com.example.library.dto.response.BookResponse;
import com.example.library.model.Book;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface BookMapper 
{
     Book ToEntity(BookRequest request);
     BookResponse ToResponse(Book entity);
     void updateEntityFromRequest(BookRequest request, @MappingTarget Book entity);
}
