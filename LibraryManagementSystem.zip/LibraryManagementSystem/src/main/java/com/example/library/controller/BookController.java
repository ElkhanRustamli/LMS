package com.example.library.controller;
import com.example.library.dto.request.BookRequest;
import com.example.library.dto.response.BookImageResponse;
import com.example.library.dto.response.BookResponse;
import com.example.library.service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping(value = "/api/book")
public class BookController
{
    private final BookService bookService;

    @PostMapping(value = "/add")
    @ResponseStatus(value = HttpStatus.CREATED)
    public void addBook(@RequestBody BookRequest bookRequest)
    {
        bookService.addBook(bookRequest);
    }

    @PutMapping(value = "/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public void updateBook(
            @PathVariable(value = "id") long bookId,
            @RequestBody BookRequest bookRequest
    ){
        bookService.updateBook(bookId, bookRequest);
    }

    @DeleteMapping(value = "/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public void deleteBook(@PathVariable(value = "id") long bookId)
    {
        bookService.deleteBook(bookId);
    }

    @PatchMapping(value = "/{id}/update-stock")
    @ResponseStatus(value = HttpStatus.OK)
    public void updateBookStock(
            @PathVariable(value = "id") long bookId,
            @RequestParam(value = "stock", required = true) int stock
    ){
        bookService.updateBookStock(bookId, stock);
    }

    @GetMapping(value = "/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public BookResponse getBookById(@PathVariable(value = "id") long bookId)
    {
        return bookService.getBookById(bookId);
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
     public List<BookResponse> getBooks() {

        return bookService.getBooks();
     }

    @GetMapping(value = "/get-by-category-id")
    @ResponseStatus(value = HttpStatus.OK)
    public List<BookResponse> getBooksByCategoryId(
            @RequestParam(value = "categoryId") long categoryId
    ) {
        return bookService.getBooksByCategoryId(categoryId);
    }

    @GetMapping(value = "/get-by-author-id")
    @ResponseStatus(value = HttpStatus.OK)
    public List<BookResponse> getBooksByAuthorId(
            @RequestParam(value = "authorId", required = true) long authorId
    ){
        return bookService.getBooksByAuthorId(authorId);
    }

    @GetMapping(value = "/search-by-title")
    public List<BookResponse> searchBooksByTitle(
            @RequestParam(value = "title", required = true) String title
    ){
        return bookService.searchBooksByTitle(title);
    }

    @PostMapping(value = "/{id}/upload-image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Void> uploadBookImage(
            @PathVariable(value = "id") long bookId,
            @RequestParam("file") MultipartFile file) {

        bookService.uploadBookImage(bookId, file);
        return ResponseEntity.ok().build();
    }

    @GetMapping(value = "/{id}/image")
    public ResponseEntity<byte[]> getBookImage(@PathVariable(value = "id") long bookId) {
        BookImageResponse imageResponse = bookService.getBookImage(bookId);

        // MIME type-i Amazon S3 cavabından alırıq
        String contentType = imageResponse.getContentType();
        if (contentType == null || contentType.isBlank()) {
            contentType = "application/octet-stream"; // Default binary type
        }

        return ResponseEntity
                .ok()
                .contentType(MediaType.parseMediaType(contentType))
                .body(imageResponse.getImageData());
    }
}