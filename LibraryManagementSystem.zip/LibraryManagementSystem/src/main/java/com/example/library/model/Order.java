package com.example.library.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Data
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "orders")
public class Order
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;     

    @ToString.Exclude
    @ManyToOne
    @JoinColumn(name = "book_id")
    private Book book;

    @ToString.Exclude
    @ManyToOne
    @JoinColumn(name = "student_id")
    private Student student;

    @Builder.Default
    @Column()
    private LocalDateTime orderTimestamp = LocalDateTime.now();

    @Builder.Default
    @Column()
    private LocalDateTime returnTimestamp = LocalDateTime.now();
}
