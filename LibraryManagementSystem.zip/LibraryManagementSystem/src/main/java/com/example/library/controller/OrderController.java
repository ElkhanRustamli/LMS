package com.example.library.controller;
import com.example.library.dto.request.OrderRequest;
import com.example.library.dto.response.OrderResponse;
import com.example.library.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping(value = "/api/order")
public class OrderController 
{
    private final OrderService orderService;

    @PostMapping(value = "/add")
    @ResponseStatus(value = HttpStatus.CREATED)
    public void addOrder(@RequestBody OrderRequest orderRequest)
    {
        orderService.addOrder(orderRequest);
    }

    @PutMapping(value = "/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public void updateOrder(
            @PathVariable(value = "id") long orderId,
            @RequestBody OrderRequest orderRequest
    ){
        orderService.updateOrder(orderId, orderRequest);
    }

    @DeleteMapping(value = "/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public void deleteOrder(@PathVariable(value = "id") long orderId)
    {
        orderService.deleteOrder(orderId);
    }

    @GetMapping
    @ResponseStatus(value = HttpStatus.OK)
    public List<OrderResponse> getOrders() {

    return orderService.getOrders();
   }

    @GetMapping(value = "/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public OrderResponse getOrderById(@PathVariable(value = "id") long orderId)
    {
        return orderService.getOrderById(orderId);
    }


    @GetMapping(value = "/get-by-student-id")
    @ResponseStatus(value = HttpStatus.OK)
     public List<OrderResponse> getOrdersByStudentId(@RequestParam(value = "studentId") long studentId)
    {
         return orderService.getOrdersByStudentId(studentId);
    }


    @PostMapping(value = "/{id}/return-order-book")
    @ResponseStatus(value = HttpStatus.OK)
    public void returnOrderBook(@PathVariable(value = "id") long orderId)
    {
        orderService.returnOrderBook(orderId);
    }

}

