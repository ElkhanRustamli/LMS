package com.example.library.service;
import com.example.library.exception.OrderNotFoundException;
import com.example.library.mapper.OrderMapper;
import com.example.library.dto.request.OrderRequest;
import com.example.library.dto.response.OrderResponse;
import com.example.library.model.Order;
import com.example.library.model.Student;
import com.example.library.repository.OrderRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderService
{
    private final OrderRepository orderRepository;
    private final OrderMapper orderMapper;
    private final BookService bookService;
    private final StudentService studentService;

    @Transactional
    public void addOrder(OrderRequest orderRequest) {

        Order order = orderMapper.ToEntity(orderRequest);

        order.setBook(bookService.getBookEntityById(orderRequest.getBookId()));

        order.setStudent(studentService.getStudentEntityById(orderRequest.getStudentId()));

        // Götürmə tarixi (sifarişin verildiyi vaxt) təyin edilir
        order.setOrderTimestamp(LocalDateTime.now());

        // Qaytarma tarixi təyin edilmir ilk dəfə sıfırlanmış olur)
        order.setReturnTimestamp(null);

        orderRepository.save(order);

        bookService.updateBookStock(order.getBook().getId(), order.getBook().getStock() - 1);

        log.info("A new order has been created for book ID: {} and student ID: {}", orderRequest.getBookId(), orderRequest.getStudentId());
    }

    @Transactional
    public void returnOrderBook(long orderId) {

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Unable to locate the order with ID : " + orderId));

        bookService.updateBookStock(order.getBook().getId(), order.getBook().getStock() + 1);

        // Qaytarma tarixi təyin edirik
        LocalDateTime returnTime = LocalDateTime.now();

        order.setReturnTimestamp(returnTime);

        orderRepository.deleteById(orderId);

        log.info("Order with ID {} has been returned and deleted", orderId);
    }
    @Transactional
    public void updateOrder(long orderId, OrderRequest orderRequest)
    {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Order with ID " + orderId + " not found"));

        orderMapper.updateEntityFromRequest(orderRequest, order);

        orderRepository.save(order);

        log.info("Successfully updated the order with ID: {}", orderId);
    }


    @Transactional
    public void deleteOrder(long orderId)
    {
        orderRepository.deleteById(orderId);

        log.info("Order with ID {} has been deleted", orderId);
    }

    public List<OrderResponse> getOrders() {

        List<Order> orderEntities = orderRepository.findAll();

        List<OrderResponse> orderResponses = orderEntities.stream()
                .map(orderMapper::ToResponse)
                .collect(Collectors.toList());

        log.info("Fetched all orders from the database");

        return orderResponses;
    }

    public OrderResponse getOrderById(long orderId)
    {

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException("Unable to locate the order with ID : " + orderId));

        OrderResponse orderResponse = orderMapper.ToResponse(order);

        log.info("Successfully fetched order with ID: {}", orderId);

        return orderResponse;
    }

    public List<OrderResponse> getOrdersByStudentId(long studentId) {

        Student student = studentService.getStudentEntityById(studentId);

        List<Order> orderEntities = orderRepository.findByStudent(student);

        List<OrderResponse> orderResponses = orderEntities.stream()
                .map(orderMapper::ToResponse)
                .collect(Collectors.toList());

        log.info("Successfully retrieved orders for student with ID: {}", studentId);

        return orderResponses;
    }
}
