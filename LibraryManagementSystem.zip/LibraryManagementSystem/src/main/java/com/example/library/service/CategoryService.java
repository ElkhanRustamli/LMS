package com.example.library.service;
import com.example.library.exception.CategoryNotFoundException;
import com.example.library.mapper.CategoryMapper;
import com.example.library.dto.request.CategoryRequest;
import com.example.library.dto.response.CategoryResponse;
import com.example.library.model.Category;
import com.example.library.repository.CategoryRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CategoryService
{
    private final CategoryRepository categoryRepository;
    private final CategoryMapper categoryMapper;

    @Transactional
    public void addCategory(CategoryRequest categoryRequest)
    {
        Category category = categoryMapper.ToEntity(categoryRequest);
        categoryRepository.save(category);

        log.info("A new category was created: {}", category.getName());
    }

    @Transactional
    public void updateCategory(long categoryId, CategoryRequest categoryRequest)
    {
        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new CategoryNotFoundException("No category found with ID " + categoryId));

        categoryMapper.updateEntityFromRequest(categoryRequest, category);
        categoryRepository.save(category);

        log.info("Updated category with ID: {}", categoryId);
    }

    @Transactional
    public void deleteCategory(long categoryId)
    {
        categoryRepository.deleteById(categoryId);

        log.info("Category with ID {} was deleted", categoryId);
    }

    public CategoryResponse getCategoryById(long categoryId)
    {

        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new CategoryNotFoundException("Category with ID " + categoryId + " does not exist."));

        CategoryResponse categoryResponse = categoryMapper.ToResponse(category);

        log.info("Fetched category with ID: {}", categoryId);

        return categoryResponse;
    }

    public List<CategoryResponse> getAllCategories()
    {
        List<Category> categoryEntities = categoryRepository.findAll();

        List<CategoryResponse> categoryResponses = categoryEntities.stream()
                .map(categoryMapper::ToResponse).collect(Collectors.toList());
        log.info("Fetched all categories from the database");

        return categoryResponses;
    }

    public Category getCategoryEntityById(long categoryId)
    {
        return categoryRepository.findById(categoryId)
                .orElseThrow(() -> new CategoryNotFoundException("No category found with ID " + categoryId));
    }

    public List<CategoryResponse> searchCategoriesByName(String name) {
        List<Category> categories = categoryRepository.findByNameContainingIgnoreCase(name);
        return categories.stream()
                .map(categoryMapper::ToResponse)
                .toList();
    }
    //   Kategoriyani sayina gorə çeşidləyir
    public List<CategoryResponse> getCategoriesSortedByBookCount() {
        List<Category> categories = categoryRepository.findAllOrderByBookCountDesc();
        return categories.stream()
                .map(categoryMapper::ToResponse)
                .toList();
    }
}
