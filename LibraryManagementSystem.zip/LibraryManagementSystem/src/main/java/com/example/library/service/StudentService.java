package com.example.library.service;
import com.example.library.exception.FinCodeAlreadyExistsException;
import com.example.library.exception.StudentNotFoundException;
import com.example.library.mapper.StudentMapper;
import com.example.library.dto.request.StudentRequest;
import com.example.library.dto.response.StudentResponse;
import com.example.library.model.Student;
import com.example.library.repository.StudentRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class StudentService
{
    private final StudentRepository studentRepository;
    private final StudentMapper studentMapper;

    @Transactional
    public void addStudent(StudentRequest studentRequest)
    {
        try
        {
            this.getStudentByFinCode(studentRequest.getFinCode());
            throw new FinCodeAlreadyExistsException("A student with this fin code already exists.");
        }
        catch (StudentNotFoundException e) {}

        Student student = studentMapper.ToEntity(studentRequest);
        studentRepository.save(student);

        log.info("A new student was successfully created: {}", student.toString());
    }
    @Transactional
    public void deleteStudent(long studentId)
    {
        studentRepository.deleteById(studentId);

        log.info("Student with ID: {} has been deleted.", studentId);
    }

    @Transactional
    public void deleteAllStudents() {
        studentRepository.deleteAll();
        log.info("All students has been deleted.");
    }
    public List<StudentResponse> getStudentsByName(String name) {
        List<Student> students = studentRepository.findByFirstNameContainingIgnoreCase(name);
        return students.stream()
                .map(studentMapper::ToResponse)
                .toList();
    }

    public StudentResponse getStudentByFinCode(String finCode)
    {
        Student student = studentRepository.findByFinCode(finCode)
                .orElseThrow(() -> new StudentNotFoundException("No student found with this fin code: " + finCode));

        StudentResponse studentResponse = studentMapper.ToResponse(student);

        log.info("Student with fin code: {} was retrieved.", finCode);

        return studentResponse;
    }

    public StudentResponse getStudentById(long studentId)
    {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new StudentNotFoundException("Student with the given ID not found: " + studentId));

        StudentResponse studentResponse = studentMapper.ToResponse(student);

        log.info("Student with ID: {} was successfully retrieved.", studentId);

        return studentResponse;
    }

    public List<StudentResponse> getStudents() {
        List<Student> studentEntities = studentRepository.findAll();

        return studentEntities.stream()
                .map(studentMapper::ToResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public void updateStudent(long studentId, StudentRequest studentRequest)
    {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new StudentNotFoundException("No student found with ID: " + studentId));

        studentMapper.updateEntityFromRequest(studentRequest, student);

        studentRepository.save(student);

        log.info("Student data with ID: {} was updated successfully.", studentId);
    }

   public Student getStudentEntityById(long studentId)
    {
        return studentRepository.findById(studentId)
                .orElseThrow(() -> new StudentNotFoundException("No student found with the ID: " + studentId));
    }
}
