package com.example.library.service;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.example.library.exception.AmazonS3Exception;
import com.example.library.dto.response.BookImageResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.io.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class AmazonS3Service {

    private final AmazonS3 s3Client;

    @Value("${app.aws.bucket-name}")
    private String bucketName;

    public void uploadFile(String key, InputStream inputStream, long contentLength, String contentType) {
        try {
            // Faylın metadata məlumatlarını təyin edirik
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentLength(contentLength);
            metadata.setContentType(contentType);

            PutObjectRequest request = new PutObjectRequest(bucketName, key, inputStream, metadata);
            s3Client.putObject(request);

            log.info("File {} successfully uploaded to S3 bucket {}", key, bucketName);
        } catch (Exception e) {
            log.error("Error uploading file to S3: {}", e.getMessage());
            throw new AmazonS3Exception("Error uploading file: " + e.getMessage());
        }
    }

    public BookImageResponse getFile(String key) {
        try {
            S3Object s3Object = s3Client.getObject(bucketName, key);
            byte[] fileBytes = s3Object.getObjectContent().readAllBytes();

            String contentType = s3Object.getObjectMetadata().getContentType();

            log.info("File {} has been successfully fetched from S3 bucket {}", key, bucketName);

            return BookImageResponse.builder()
                    .fileLink(key)
                    .imageData(fileBytes)
                    .contentType(contentType)
                    .build();
        } catch (IOException e) {
            throw new AmazonS3Exception("Error while retrieving file: " + e.getMessage());
        }
    }
}
