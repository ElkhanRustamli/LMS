package com.example.library.controller;
import com.example.library.dto.request.StudentRequest;
import com.example.library.dto.response.StudentResponse;
import com.example.library.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping(value = "/api/student")
public class StudentController 
{
    private final StudentService studentService; 

    @PostMapping(value = "/add")
    @ResponseStatus(value = HttpStatus.CREATED)
    public void addStudent(@RequestBody StudentRequest studentRequest)
    {
        studentService.addStudent(studentRequest);
    }

    @PutMapping (value = "/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public void updateStudent(
            @PathVariable(value = "id") long studentId,
            @RequestBody StudentRequest studentRequest
    ){
        studentService.updateStudent(studentId, studentRequest);
    }

    @DeleteMapping(value = "/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public void deleteStudent(@PathVariable(value = "id") long studentId)
    {
        studentService.deleteStudent(studentId);
    }

    @GetMapping(value = "/search-by-fin-code")
    @ResponseStatus(value = HttpStatus.OK)
    public StudentResponse searchStudentByFinCode(
        @RequestParam(value = "finCode", required = true) String finCode
    ){
        return studentService.getStudentByFinCode(finCode);
    }

    @GetMapping(value = "/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public StudentResponse searchStudentById(@PathVariable(value = "id") long studentId)
    {
        return studentService.getStudentById(studentId);
    }
    @GetMapping("/search-by-name")
    @ResponseStatus(HttpStatus.OK)
    public List<StudentResponse> searchStudentsByName(@RequestParam String name) {
        return studentService.getStudentsByName(name);
    }
    @DeleteMapping
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteAllStudents() {
        studentService.deleteAllStudents();
    }


@GetMapping
@ResponseStatus(value = HttpStatus.OK)
public List<StudentResponse> getStudents() {
    return studentService.getStudents();
}



}
