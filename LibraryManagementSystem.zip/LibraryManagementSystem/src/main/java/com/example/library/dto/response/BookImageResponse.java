package com.example.library.dto.response;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BookImageResponse {
    private String fileLink;
    private byte[] imageData;
    private String contentType;  // Yeni field əlavə edildi
}
