package com.example.library.exception;

public class CategoryNotFoundException extends RuntimeException
{
    public CategoryNotFoundException(String message)
    {
        super(message);
    }
}
