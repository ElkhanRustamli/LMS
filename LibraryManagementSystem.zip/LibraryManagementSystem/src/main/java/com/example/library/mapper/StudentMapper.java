package com.example.library.mapper;

import com.example.library.dto.request.StudentRequest;
import com.example.library.dto.response.StudentResponse;
import com.example.library.model.Student;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface StudentMapper 
{
     Student ToEntity(StudentRequest request);
     StudentResponse ToResponse(Student entity);
     void updateEntityFromRequest(StudentRequest request, @MappingTarget Student entity);
}
