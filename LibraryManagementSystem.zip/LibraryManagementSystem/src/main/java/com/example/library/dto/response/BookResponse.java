package com.example.library.dto.response;
import lombok.*;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BookResponse 
{
    private long id; 
    private String title; 
    private int stock; 

    @ToString.Exclude
    private List<AuthorResponse> authors; 

    @ToString.Exclude
    private CategoryResponse category; 
}
