package com.example.library.service;
import java.util.List;
import java.util.stream.Collectors;
import com.example.library.model.Author;
import org.springframework.stereotype.Service;
import com.example.library.exception.AuthorNotFoundException;
import com.example.library.mapper.AuthorMapper;
import com.example.library.dto.request.AuthorRequest;
import com.example.library.dto.response.AuthorResponse;
import com.example.library.repository.AuthorRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthorService {

    private final AuthorRepository authorRepository;
    private final AuthorMapper authorMapper;

    @Transactional
    public void addAuthor(AuthorRequest authorRequest) {
        Author author = authorMapper.ToEntity(authorRequest);
        authorRepository.save(author);
        log.info("A new author has been added: {}", author);
    }

    @Transactional
    public void updateAuthor(Long id, AuthorRequest authorRequest) {

        Author author = authorRepository.findById(id)
                .orElseThrow(() -> new AuthorNotFoundException("No author exists with ID: " + id));

        authorMapper.updateEntityFromRequest(authorRequest, author);

        authorRepository.save(author);
        log.info("Successfully updated author with ID: {}", id);
    }

    @Transactional
    public void deleteAuthor(Long id) {
        authorRepository.deleteById(id);
        log.info("Successfully removed author with ID: {}", id);
    }

    public AuthorResponse getAuthorById(Long id) {
        Author author = authorRepository.findById(id)
                .orElseThrow(() -> new AuthorNotFoundException("No author found with ID: " + id));

        AuthorResponse authorResponse = authorMapper.ToResponse(author);
        log.info("Fetched author with ID: {}", id);

        return authorResponse;
    }


    public List<AuthorResponse> getAuthors() {
        List<Author> authorEntities = authorRepository.findAll();

        return authorEntities.stream()
                .map(authorMapper::ToResponse)
                .collect(Collectors.toList());
    }

    public List<AuthorResponse> getAuthorsByFullName(String fullName) {
        List<Author> authorEntities = authorRepository.searchByFullName(fullName);
        List<AuthorResponse> authorResponses = authorEntities.stream()
                .map(authorMapper::ToResponse)
                .collect(Collectors.toList());
        log.info("Found {} authors matching the given name", authorResponses.size());
        return authorResponses;
    }

    public Author getAuthorEntityById(long authorId) {
        return authorRepository.findById(authorId)
                .orElseThrow(() -> new AuthorNotFoundException("Unable to locate an author with ID: " + authorId));
    }

    // Müəllifləri kitab sayına görə azalan sırada qaytaran metod
    public List<AuthorResponse> getAuthorsSortedByBookCount() {
        List<Author> authors = authorRepository.findAllOrderByBookCountDesc();
        return authors.stream()
                .map(authorMapper::ToResponse)
                .toList();
    }

}
