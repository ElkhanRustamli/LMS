
package com.example.library.controller;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.example.library.dto.request.AuthorRequest;
import com.example.library.dto.response.AuthorResponse;
import com.example.library.service.AuthorService;
import lombok.RequiredArgsConstructor;



@RestController
@RequiredArgsConstructor
@RequestMapping(value = "/api/author")
public class AuthorController
{
    private final AuthorService authorService;

    @PostMapping(value ="/add" )
    @ResponseStatus(value = HttpStatus.CREATED)
    public void addAuthor(@RequestBody AuthorRequest authorRequest)
    {
        authorService.addAuthor(authorRequest);
    }

    @DeleteMapping(value = "/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public void deleteAuthor(@PathVariable(value = "id") long authorId)
    {
        authorService.deleteAuthor(authorId);
    }

    @PutMapping(value = "/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public void updateAuthor(
            @PathVariable(value = "id") long authorId,
            @RequestBody AuthorRequest authorRequest
    ){
        authorService.updateAuthor(authorId, authorRequest);
    }

    @GetMapping("/sorted-by-books")
    @ResponseStatus(HttpStatus.OK)
    public List<AuthorResponse> getAuthorsSortedByBookCount() {
        return authorService.getAuthorsSortedByBookCount();
    }

    @GetMapping(value = "/{id}")
    @ResponseStatus(value = HttpStatus.OK)
    public AuthorResponse getAuthorById(@PathVariable(value = "id") long authorId)
    {
        return authorService.getAuthorById(authorId);
    }

    @GetMapping
    @ResponseStatus(value = HttpStatus.OK)
    public List<AuthorResponse> getAuthors() {
        return authorService.getAuthors();
    }

    @GetMapping(value = "/search-by-full-name")
    @ResponseStatus(value = HttpStatus.OK)
    public List<AuthorResponse> getAuthorsByFullName(
            @RequestParam(value = "fullName") String fullName) {

        return authorService.getAuthorsByFullName(fullName);
    }
}
