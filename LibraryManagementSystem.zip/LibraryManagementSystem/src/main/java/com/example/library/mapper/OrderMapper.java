package com.example.library.mapper;

import com.example.library.dto.request.OrderRequest;
import com.example.library.dto.response.OrderResponse;
import com.example.library.model.Order;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface OrderMapper 
{
     Order ToEntity(OrderRequest request);
     OrderResponse ToResponse(Order entity);
     void updateEntityFromRequest(OrderRequest request, @MappingTarget Order entity);
}
